# Instruções para Deploy do Site Apocalypse Academy em Plataformas Alternativas

Este guia fornece instruções detalhadas para fazer o deploy do site Apocalypse Academy em diferentes plataformas de hospedagem. Além da Vercel (recomendada para sites Next.js), existem outras opções excelentes que você pode considerar.

## Opção 1: Deploy no Netlify

O Netlify é uma plataforma popular e fácil de usar para hospedagem de sites estáticos e aplicações web.

### Passo a Passo:

1. **Criar uma conta no Netlify**:
   - Acesse [netlify.com](https://www.netlify.com/)
   - Clique em "Sign up" e crie uma conta (você pode usar GitHub, GitLab, Bitbucket ou email)

2. **Preparar os arquivos**:
   - Descompacte o arquivo `apocalypse-academy-website-export.zip`
   - Você verá uma pasta chamada `export` - esta contém os arquivos compilados para produção

3. **Fazer o deploy**:
   - No dashboard do Netlify, clique em "Sites" no menu superior
   - Clique no botão "Add new site" e selecione "Deploy manually"
   - Arraste e solte a pasta `export` na área indicada ou clique para selecionar os arquivos
   - O Netlify iniciará automaticamente o upload e deploy dos arquivos

4. **Configurar o site**:
   - Após o deploy, seu site estará disponível em um URL aleatório como `random-name.netlify.app`
   - Clique em "Site settings" para personalizar o nome do site (URL)
   - Em "Domain management", você pode configurar um domínio personalizado se desejar

5. **Verificar o site**:
   - Clique no link do seu site para verificar se tudo está funcionando corretamente
   - Navegue por todas as páginas para garantir que os links e recursos estão funcionando

## Opção 2: Deploy no GitHub Pages

O GitHub Pages é uma opção gratuita para hospedar sites diretamente de um repositório GitHub.

### Passo a Passo:

1. **Criar uma conta no GitHub**:
   - Acesse [github.com](https://github.com/)
   - Clique em "Sign up" e crie uma conta se ainda não tiver uma

2. **Criar um novo repositório**:
   - Clique no botão "+" no canto superior direito e selecione "New repository"
   - Nomeie o repositório como `apocalypse-academy` ou outro nome de sua preferência
   - Mantenha o repositório público e clique em "Create repository"

3. **Preparar os arquivos**:
   - Descompacte o arquivo `apocalypse-academy-website-export.zip`
   - Renomeie a pasta `export` para `docs`

4. **Fazer upload dos arquivos**:
   - Na página do seu repositório, clique em "Add file" e selecione "Upload files"
   - Arraste e solte a pasta `docs` ou selecione os arquivos para upload
   - Adicione uma mensagem de commit como "Initial commit" e clique em "Commit changes"

5. **Configurar o GitHub Pages**:
   - Vá para "Settings" do repositório
   - Role até a seção "GitHub Pages"
   - Em "Source", selecione "main branch" e "/docs" como pasta
   - Clique em "Save"

6. **Acessar o site**:
   - Após alguns minutos, seu site estará disponível em `https://seu-usuario.github.io/apocalypse-academy/`
   - O link exato será mostrado na seção GitHub Pages das configurações

## Opção 3: Deploy no Firebase Hosting

O Firebase Hosting da Google oferece hospedagem rápida e segura com CDN global.

### Passo a Passo:

1. **Criar uma conta no Firebase**:
   - Acesse [firebase.google.com](https://firebase.google.com/)
   - Clique em "Get started" e faça login com sua conta Google

2. **Instalar Firebase CLI**:
   - Abra um terminal ou prompt de comando
   - Instale o Firebase CLI globalmente:
     ```bash
     npm install -g firebase-tools
     ```

3. **Inicializar o projeto Firebase**:
   - Faça login no Firebase:
     ```bash
     firebase login
     ```
   - Navegue até a pasta onde você descompactou o arquivo `apocalypse-academy-website-export.zip`
   - Inicialize o Firebase:
     ```bash
     firebase init
     ```
   - Selecione "Hosting" quando perguntado sobre quais recursos deseja configurar
   - Selecione "Create a new project" ou use um projeto existente
   - Quando perguntado sobre o diretório público, digite `export`
   - Responda "Yes" para configurar como aplicação de página única
   - Responda "No" para não sobrescrever o arquivo index.html

4. **Fazer o deploy**:
   - Execute o comando:
     ```bash
     firebase deploy
     ```

5. **Acessar o site**:
   - Após o deploy, você receberá um URL como `https://seu-projeto.web.app`
   - Acesse este URL para verificar seu site

## Opção 4: Deploy em Hospedagem Tradicional (cPanel)

Se você já possui uma hospedagem web tradicional com cPanel, pode usar esta opção.

### Passo a Passo:

1. **Preparar os arquivos**:
   - Descompacte o arquivo `apocalypse-academy-website-export.zip`
   - A pasta `export` contém os arquivos compilados para produção

2. **Acessar o cPanel**:
   - Faça login no painel de controle da sua hospedagem (cPanel)
   - Localize o "Gerenciador de Arquivos" ou "File Manager"

3. **Fazer upload dos arquivos**:
   - Navegue até a pasta pública do seu domínio (geralmente `public_html`)
   - Clique em "Upload" e selecione todos os arquivos da pasta `export`
   - Alternativamente, você pode usar um cliente FTP como FileZilla para fazer o upload

4. **Configurar o domínio**:
   - Se necessário, configure seu domínio para apontar para a pasta onde você fez o upload dos arquivos
   - Isso geralmente é feito na seção "Domains" ou "Subdomains" do cPanel

5. **Verificar o site**:
   - Acesse seu domínio (ex: `https://seudominio.com`) para verificar se o site está funcionando corretamente

## Considerações Finais

- **Domínio personalizado**: Todas as plataformas mencionadas permitem o uso de domínios personalizados. Se você já possui um domínio, pode configurá-lo para apontar para seu site hospedado.

- **HTTPS**: Todas as plataformas oferecem HTTPS gratuito, garantindo que seu site seja seguro para os visitantes.

- **Escalabilidade**: Se seu site crescer e precisar de recursos adicionais, todas estas plataformas oferecem planos pagos com mais recursos.

- **Suporte a Next.js**: Vercel e Netlify oferecem suporte nativo a aplicações Next.js, tornando-as as opções mais recomendadas para este projeto específico.

Escolha a plataforma que melhor atende às suas necessidades e orçamento. Se precisar de ajuda adicional com qualquer uma destas opções de deploy, não hesite em solicitar assistência.
